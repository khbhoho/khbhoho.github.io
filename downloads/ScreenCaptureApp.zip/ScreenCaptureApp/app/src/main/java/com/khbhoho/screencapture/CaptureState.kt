package com.khbhoho.screencapture

import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** 서비스 ↔ 화면 사이에서 공유하는 상태. */
object CaptureState {

    data class Capture(val uri: Uri, val name: String)

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    private val _lastCapture = MutableStateFlow<Capture?>(null)
    val lastCapture: StateFlow<Capture?> = _lastCapture.asStateFlow()

    internal fun setConnected(value: Boolean) {
        _connected.value = value
    }

    internal fun onCaptured(capture: Capture) {
        _lastCapture.value = capture
    }
}
