package com.khbhoho.screencapture

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * 알림의 [지금 촬영] 버튼용 투명 액티비티.
 * 알림창을 닫게 만들고, 서비스에 촬영을 요청한 뒤 바로 사라진다.
 * (지금 보고 있는 다른 앱 화면을 그대로 찍고, 이 앱으로 복귀하지 않는다.)
 */
class CaptureShortcutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startService(
            Intent(this, ScreenCaptureService::class.java)
                .setAction(ScreenCaptureService.ACTION_CAPTURE)
                .putExtra(
                    ScreenCaptureService.EXTRA_DELAY_MS,
                    ScreenCaptureService.NOTIFICATION_CAPTURE_DELAY_MS
                )
                .putExtra(ScreenCaptureService.EXTRA_RETURN_TO_APP, false)
        )
        finish()
        overridePendingTransition(0, 0)
    }
}
