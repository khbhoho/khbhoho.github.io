package com.khbhoho.screencapture

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.ImageDecoder
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var connectButton: MaterialButton
    private lateinit var disconnectButton: MaterialButton
    private lateinit var overlayButton: MaterialButton
    private lateinit var lastCaptureText: TextView
    private lateinit var preview: ImageView

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java)
                    .setAction(ScreenCaptureService.ACTION_START)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                ContextCompat.startForegroundService(this, intent)
                // 연결되면 이 앱은 뒤로 물러나고, 이후엔 플로팅 버튼으로 촬영한다.
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, R.string.toast_denied, Toast.LENGTH_SHORT).show()
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            launchProjectionRequest()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        statusText = findViewById(R.id.statusText)
        connectButton = findViewById(R.id.connectButton)
        disconnectButton = findViewById(R.id.disconnectButton)
        overlayButton = findViewById(R.id.overlayButton)
        lastCaptureText = findViewById(R.id.lastCaptureText)
        preview = findViewById(R.id.preview)

        connectButton.setOnClickListener { connect() }
        disconnectButton.setOnClickListener { disconnect() }
        overlayButton.setOnClickListener { openOverlaySettings() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { CaptureState.connected.collect { updateConnectionUi(it) } }
                launch { CaptureState.lastCapture.collect { showCapture(it) } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateOverlayUi()
    }

    // ---------------------------------------------------------------- 동작

    private fun connect() {
        // 플로팅 버튼을 띄우려면 "다른 앱 위에 표시" 권한이 반드시 필요하다.
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.overlay_needed, Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchProjectionRequest()
        }
    }

    private fun launchProjectionRequest() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // "전체 화면"만 선택되게 한다 (다른 앱 화면을 찍어야 하므로)
            manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            manager.createScreenCaptureIntent()
        }
        projectionLauncher.launch(intent)
    }

    private fun disconnect() {
        startService(
            Intent(this, ScreenCaptureService::class.java)
                .setAction(ScreenCaptureService.ACTION_STOP)
        )
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
        )
    }

    // ---------------------------------------------------------------- UI

    private fun updateConnectionUi(connected: Boolean) {
        statusText.setText(if (connected) R.string.status_connected else R.string.status_disconnected)
        connectButton.isEnabled = !connected
        disconnectButton.isEnabled = connected
    }

    private fun updateOverlayUi() {
        val granted = Settings.canDrawOverlays(this)
        overlayButton.isEnabled = !granted
        overlayButton.setText(if (granted) R.string.overlay_ok else R.string.btn_overlay)
    }

    private suspend fun showCapture(capture: CaptureState.Capture?) {
        if (capture == null) {
            lastCaptureText.setText(R.string.no_capture)
            preview.setImageDrawable(null)
            return
        }
        lastCaptureText.text = capture.name
        val bitmap = withContext(Dispatchers.IO) {
            try {
                val source = ImageDecoder.createSource(contentResolver, capture.uri)
                ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    val scale = PREVIEW_MAX_PX.toFloat() / maxOf(info.size.width, info.size.height)
                    if (scale < 1f) {
                        decoder.setTargetSize(
                            (info.size.width * scale).toInt().coerceAtLeast(1),
                            (info.size.height * scale).toInt().coerceAtLeast(1)
                        )
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
        preview.setImageBitmap(bitmap)
    }

    companion object {
        private const val PREVIEW_MAX_PX = 1280
    }
}
