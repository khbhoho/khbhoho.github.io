package com.khbhoho.screencapture

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.ImageDecoder
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var connectButton: MaterialButton
    private lateinit var disconnectButton: MaterialButton
    private lateinit var captureButton: MaterialButton
    private lateinit var overlayButton: MaterialButton
    private lateinit var delayLabel: TextView
    private lateinit var delaySeek: SeekBar
    private lateinit var returnSwitch: MaterialSwitch
    private lateinit var lastCaptureText: TextView
    private lateinit var preview: ImageView

    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    /** "스크린샷 찍기"를 눌렀는데 아직 연결 전이면, 연결 직후 바로 촬영한다. */
    private var captureAfterConnect = false

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java)
                    .setAction(ScreenCaptureService.ACTION_START)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                ContextCompat.startForegroundService(this, intent)

                if (captureAfterConnect) {
                    captureAfterConnect = false
                    // 권한 창이 닫히는 애니메이션이 끝난 뒤 촬영
                    captureButton.postDelayed({ sendCaptureAndGoBack() }, 400)
                }
            } else {
                captureAfterConnect = false
                Toast.makeText(this, R.string.toast_denied, Toast.LENGTH_SHORT).show()
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // 거부해도 캡처는 동작한다 (알림만 안 보임)
            launchProjectionRequest()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        statusText = findViewById(R.id.statusText)
        connectButton = findViewById(R.id.connectButton)
        disconnectButton = findViewById(R.id.disconnectButton)
        captureButton = findViewById(R.id.captureButton)
        overlayButton = findViewById(R.id.overlayButton)
        delayLabel = findViewById(R.id.delayLabel)
        delaySeek = findViewById(R.id.delaySeek)
        returnSwitch = findViewById(R.id.returnSwitch)
        lastCaptureText = findViewById(R.id.lastCaptureText)
        preview = findViewById(R.id.preview)

        connectButton.setOnClickListener { connect() }
        disconnectButton.setOnClickListener { disconnect() }
        captureButton.setOnClickListener { requestCapture() }
        overlayButton.setOnClickListener { openOverlaySettings() }

        delaySeek.progress = prefs.getInt(KEY_DELAY_STEP, 1)
        updateDelayLabel()
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                updateDelayLabel()
                prefs.edit().putInt(KEY_DELAY_STEP, progress).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })

        returnSwitch.isChecked = prefs.getBoolean(KEY_RETURN, true)
        returnSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_RETURN, checked).apply()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { CaptureState.connected.collect { updateConnectionUi(it) } }
                launch { CaptureState.lastCapture.collect { showCapture(it) } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateOverlayUi()
    }

    // ---------------------------------------------------------------- 동작

    private fun delayMs(): Long = (delaySeek.progress + 1) * 500L

    private fun connect() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchProjectionRequest()
        }
    }

    private fun launchProjectionRequest() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // 특정 앱 1개가 아니라 "전체 화면"만 선택되게 한다
            // (이 앱이 뒤로 빠진 뒤 보이는 화면을 찍어야 하므로)
            manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            manager.createScreenCaptureIntent()
        }
        projectionLauncher.launch(intent)
    }

    private fun disconnect() {
        startService(
            Intent(this, ScreenCaptureService::class.java)
                .setAction(ScreenCaptureService.ACTION_STOP)
        )
    }

    /** 이 앱을 백그라운드로 보내고 → 대기 → 촬영 → (옵션) 다시 앞으로. */
    private fun requestCapture() {
        if (!CaptureState.connected.value) {
            captureAfterConnect = true
            connect()
            return
        }
        sendCaptureAndGoBack()
    }

    private fun sendCaptureAndGoBack() {
        startService(
            Intent(this, ScreenCaptureService::class.java)
                .setAction(ScreenCaptureService.ACTION_CAPTURE)
                .putExtra(ScreenCaptureService.EXTRA_DELAY_MS, delayMs())
                .putExtra(ScreenCaptureService.EXTRA_RETURN_TO_APP, returnSwitch.isChecked)
        )
        moveTaskToBack(true)
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
        )
    }

    // ---------------------------------------------------------------- UI

    private fun updateDelayLabel() {
        delayLabel.text = getString(R.string.delay_label, delayMs() / 1000f)
    }

    private fun updateConnectionUi(connected: Boolean) {
        statusText.setText(if (connected) R.string.status_connected else R.string.status_disconnected)
        connectButton.isEnabled = !connected
        disconnectButton.isEnabled = connected
    }

    private fun updateOverlayUi() {
        val granted = Settings.canDrawOverlays(this)
        overlayButton.isEnabled = !granted
        overlayButton.setText(if (granted) R.string.overlay_ok else R.string.btn_overlay)
    }

    private suspend fun showCapture(capture: CaptureState.Capture?) {
        if (capture == null) {
            lastCaptureText.setText(R.string.no_capture)
            preview.setImageDrawable(null)
            return
        }
        lastCaptureText.text = capture.name
        val bitmap = withContext(Dispatchers.IO) {
            try {
                val source = ImageDecoder.createSource(contentResolver, capture.uri)
                ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    // 미리보기용으로 축소해서 읽기
                    val scale = PREVIEW_MAX_PX.toFloat() / maxOf(info.size.width, info.size.height)
                    if (scale < 1f) {
                        decoder.setTargetSize(
                            (info.size.width * scale).toInt().coerceAtLeast(1),
                            (info.size.height * scale).toInt().coerceAtLeast(1)
                        )
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
        preview.setImageBitmap(bitmap)
    }

    companion object {
        private const val KEY_DELAY_STEP = "delay_step"
        private const val KEY_RETURN = "return_to_app"
        private const val PREVIEW_MAX_PX = 1280
    }
}
