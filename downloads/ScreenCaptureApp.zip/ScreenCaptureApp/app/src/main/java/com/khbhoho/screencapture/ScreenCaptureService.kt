package com.khbhoho.screencapture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import java.io.IOException
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MediaProjection(화면 캡처 권한)을 쥐고 있는 포그라운드 서비스.
 *
 * 한 번 "연결 허용"을 받으면 VirtualDisplay 를 계속 유지하고,
 * 촬영 요청이 오면 지정한 시간만큼 기다린 뒤(그동안 이 앱은 백그라운드로 내려가 있음)
 * 가장 최근 화면 프레임을 PNG 로 저장하고, 원하면 앱을 다시 앞으로 불러온다.
 */
class ScreenCaptureService : Service() {

    companion object {
        private const val TAG = "ScreenCaptureService"

        const val ACTION_START = "com.khbhoho.screencapture.START"
        const val ACTION_CAPTURE = "com.khbhoho.screencapture.CAPTURE"
        const val ACTION_STOP = "com.khbhoho.screencapture.STOP"

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_DELAY_MS = "delay_ms"
        const val EXTRA_RETURN_TO_APP = "return_to_app"

        private const val CHANNEL_ID = "screen_capture"
        private const val NOTIF_ID_RUNNING = 1
        private const val NOTIF_ID_SAVED = 2

        /** 알림의 [지금 촬영] 버튼으로 찍을 때는 알림창이 닫힐 시간을 준다. */
        const val NOTIFICATION_CAPTURE_DELAY_MS = 1000L
        private const val FRAME_WAIT_STEP_MS = 100L
        private const val FRAME_WAIT_MAX_ATTEMPTS = 30
    }

    private lateinit var captureThread: HandlerThread
    private lateinit var handler: Handler
    private val mainHandler = Handler(Looper.getMainLooper())

    // 아래 필드들은 모두 captureThread(handler) 위에서만 다룬다.
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestImage: Image? = null
    private var width = 0
    private var height = 0
    private var densityDpi = 0

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            // 사용자가 상태표시줄/설정에서 공유를 중지한 경우
            Log.i(TAG, "MediaProjection stopped")
            shutdown()
        }
    }

    override fun onCreate() {
        super.onCreate()
        captureThread = HandlerThread("ScreenCapture").apply { start() }
        handler = Handler(captureThread.looper)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_CAPTURE -> handleCapture(intent)
            ACTION_STOP -> handler.post { shutdown() }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.post { releaseProjection() }
        captureThread.quitSafely()
        CaptureState.setConnected(false)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- 연결

    private fun handleStart(intent: Intent) {
        // Android 14+: getMediaProjection() 전에 반드시 포그라운드 상태여야 한다.
        ServiceCompat.startForeground(
            this,
            NOTIF_ID_RUNNING,
            buildRunningNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_RESULT_DATA, Intent::class.java)
        if (resultCode != Activity.RESULT_OK || data == null) {
            handler.post { shutdown() }
            return
        }

        val manager = getSystemService(MediaProjectionManager::class.java)
        val newProjection = try {
            manager.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            Log.e(TAG, "getMediaProjection failed", e)
            null
        }
        if (newProjection == null) {
            handler.post { shutdown() }
            return
        }

        // Android 14+: createVirtualDisplay() 전에 콜백 등록이 필수.
        newProjection.registerCallback(projectionCallback, handler)

        handler.post {
            releaseProjection() // 혹시 이전 연결이 남아 있으면 정리
            projection = newProjection
            try {
                createVirtualDisplay()
                CaptureState.setConnected(true)
            } catch (e: Exception) {
                Log.e(TAG, "createVirtualDisplay failed", e)
                shutdown()
            }
        }
    }

    private fun createVirtualDisplay() {
        val proj = projection ?: return
        readScreenSize()

        val reader = newImageReader()
        imageReader = reader
        virtualDisplay = proj.createVirtualDisplay(
            "ScreenCapture",
            width, height, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
    }

    private fun newImageReader(): ImageReader =
        ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3).apply {
            setOnImageAvailableListener({ reader -> onImageAvailable(reader) }, handler)
        }

    /** 새 프레임이 올 때마다 가장 최신 것 하나만 들고 있는다. */
    private fun onImageAvailable(reader: ImageReader) {
        val image = try {
            reader.acquireLatestImage()
        } catch (e: IllegalStateException) {
            null
        } ?: return

        if (reader !== imageReader) {
            image.close()
            return
        }
        latestImage?.close()
        latestImage = image
    }

    @Suppress("DEPRECATION")
    private fun readScreenSize() {
        val display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        width = metrics.widthPixels
        height = metrics.heightPixels
        densityDpi = metrics.densityDpi
    }

    /** 화면 회전 등으로 크기가 바뀌었으면 VirtualDisplay 를 새 크기에 맞춘다. */
    private fun resizeIfNeeded() {
        val oldW = width
        val oldH = height
        readScreenSize()
        if (oldW == width && oldH == height) return

        val display = virtualDisplay ?: return
        val oldReader = imageReader
        latestImage?.close()
        latestImage = null

        val reader = newImageReader()
        imageReader = reader
        display.resize(width, height, densityDpi)
        display.surface = reader.surface
        oldReader?.close()
    }

    // ---------------------------------------------------------------- 촬영

    private fun handleCapture(intent: Intent) {
        val delayMs = intent.getLongExtra(EXTRA_DELAY_MS, NOTIFICATION_CAPTURE_DELAY_MS)
        val returnToApp = intent.getBooleanExtra(EXTRA_RETURN_TO_APP, false)

        handler.postDelayed({
            if (projection == null) {
                finishCapture(null, "화면이 연결되어 있지 않습니다", returnToApp)
                return@postDelayed
            }
            resizeIfNeeded()
            captureFrame(returnToApp, attempt = 0)
        }, delayMs)
    }

    private fun captureFrame(returnToApp: Boolean, attempt: Int) {
        val image = latestImage
        if (image == null) {
            if (attempt < FRAME_WAIT_MAX_ATTEMPTS) {
                handler.postDelayed({ captureFrame(returnToApp, attempt + 1) }, FRAME_WAIT_STEP_MS)
            } else {
                finishCapture(null, "화면 프레임을 받지 못했습니다", returnToApp)
            }
            return
        }

        try {
            val bitmap = imageToBitmap(image)
            val capture = saveBitmap(bitmap)
            bitmap.recycle()
            finishCapture(capture, null, returnToApp)
        } catch (e: Exception) {
            Log.e(TAG, "capture failed", e)
            finishCapture(null, e.message ?: e.javaClass.simpleName, returnToApp)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val buffer = plane.buffer.apply { rewind() }
        // 일부 기기는 마지막 행의 패딩이 없어 버퍼가 약간 짧다 → 부족하면 복사해서 채운다.
        val needed = rowStride * image.height
        val source: ByteBuffer = if (buffer.remaining() >= needed) {
            buffer
        } else {
            ByteBuffer.allocateDirect(needed).put(buffer).also { it.rewind() }
        }

        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(source)
        if (rowPadding == 0) return padded

        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun saveBitmap(bitmap: Bitmap): CaptureState.Capture {
        val name = "Screenshot_" +
            SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + ".png"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/ScreenCapture"
            )
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }

        val resolver = contentResolver
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri: Uri = resolver.insert(collection, values)
            ?: throw IOException("갤러리에 파일을 만들 수 없습니다")

        try {
            resolver.openOutputStream(uri)?.use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                    throw IOException("PNG 인코딩 실패")
                }
            } ?: throw IOException("파일을 열 수 없습니다")

            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return CaptureState.Capture(uri, name)
    }

    private fun finishCapture(capture: CaptureState.Capture?, error: String?, returnToApp: Boolean) {
        mainHandler.post {
            if (capture != null) {
                CaptureState.onCaptured(capture)
                Toast.makeText(this, R.string.toast_saved, Toast.LENGTH_SHORT).show()
                showSavedNotification()
            } else {
                Toast.makeText(this, getString(R.string.toast_failed, error), Toast.LENGTH_LONG).show()
            }
            if (returnToApp) bringAppToFront()
        }
    }

    // ---------------------------------------------------------------- 원상 복귀

    private fun mainActivityIntent(): Intent =
        Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
        )

    /**
     * Android 10+ 는 백그라운드에서 액티비티를 띄우는 것을 막는다.
     * "다른 앱 위에 표시" 권한이 있으면 예외가 되며, Android 15+ 는 오버레이 창이
     * 실제로 떠 있어야 하므로 1px 투명 창을 잠깐 띄운 뒤 앱을 불러온다.
     * 권한이 없으면 시도만 하고, 저장 완료 알림을 눌러 돌아올 수 있다.
     */
    private fun bringAppToFront() {
        val intent = mainActivityIntent()
        if (!Settings.canDrawOverlays(this)) {
            try {
                startActivity(intent)
            } catch (e: Exception) {
                Log.w(TAG, "background activity start blocked", e)
            }
            return
        }

        val wm = getSystemService(WindowManager::class.java)
        val overlay = View(this)
        val params = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        val added = try {
            wm.addView(overlay, params)
            true
        } catch (e: Exception) {
            Log.w(TAG, "overlay add failed", e)
            false
        }

        mainHandler.postDelayed({
            try {
                startActivity(intent)
            } catch (e: Exception) {
                Log.w(TAG, "activity start failed", e)
            }
            if (added) {
                mainHandler.postDelayed({
                    try {
                        wm.removeView(overlay)
                    } catch (_: Exception) {
                    }
                }, 1000)
            }
        }, 150)
    }

    // ---------------------------------------------------------------- 정리

    /** handler 스레드에서 호출. */
    private fun releaseProjection() {
        latestImage?.close()
        latestImage = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.let {
            it.unregisterCallback(projectionCallback)
            it.stop()
        }
        projection = null
    }

    /** handler 스레드에서 호출. */
    private fun shutdown() {
        releaseProjection()
        CaptureState.setConnected(false)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------------------------------------------------------- 알림

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildRunningNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, mainActivityIntent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // 액티비티 PendingIntent 여야 알림창이 자동으로 닫힌다.
        val capture = PendingIntent.getActivity(
            this, 1,
            Intent(this, CaptureShortcutActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_capture)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_running))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "지금 촬영", capture)
            .addAction(0, "연결 해제", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    private fun showSavedNotification() {
        val openApp = PendingIntent.getActivity(
            this, 3, mainActivityIntent(),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_capture)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_saved))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID_SAVED, notification)
        } catch (_: SecurityException) {
            // 알림 권한이 없으면 조용히 무시
        }
    }
}
