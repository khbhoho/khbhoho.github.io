package com.khbhoho.screencapture

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import java.io.IOException
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * 화면 캡처 권한(MediaProjection)을 계속 쥐고 있고, 다른 앱 위에 뜨는 플로팅 버튼을 관리하는 서비스.
 *
 * 흐름
 *  1. MainActivity 에서 화면 연결을 허용받으면 서비스가 시작된다.
 *  2. 서비스는 VirtualDisplay 를 유지하고, 화면 위에 동그란 플로팅 버튼을 띄운다.
 *  3. 사용자가 다른 앱을 켜고 플로팅 버튼을 누르면:
 *       - 버튼을 잠깐 숨긴다(스샷에 안 찍히도록)
 *       - 현재 화면 프레임을 PNG 로 저장한다
 *       - 버튼을 다시 보여준다
 *  4. 버튼을 길게 누르면 연결이 해제된다.
 */
class ScreenCaptureService : Service() {

    companion object {
        private const val TAG = "ScreenCaptureService"

        const val ACTION_START = "com.khbhoho.screencapture.START"
        const val ACTION_CAPTURE = "com.khbhoho.screencapture.CAPTURE"
        const val ACTION_STOP = "com.khbhoho.screencapture.STOP"

        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        private const val CHANNEL_ID = "screen_capture"
        private const val NOTIF_ID_RUNNING = 1

        /** 버튼을 숨긴 뒤 화면이 실제로 반영될 때까지의 여유 시간. */
        private const val HIDE_SETTLE_MS = 120L
        private const val FRAME_WAIT_STEP_MS = 60L
        private const val FRAME_WAIT_MAX_ATTEMPTS = 40
    }

    private lateinit var captureThread: HandlerThread
    private lateinit var handler: Handler
    private val mainHandler = Handler(Looper.getMainLooper())

    // 캡처 관련 필드는 captureThread(handler) 위에서만 다룬다.
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var latestImage: Image? = null
    private var width = 0
    private var height = 0
    private var densityDpi = 0

    // 플로팅 버튼은 메인 스레드에서만 다룬다.
    private var floatingView: View? = null
    private var floatingParams: WindowManager.LayoutParams? = null
    private var capturing = false

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped")
            mainHandler.post { stopEverything() }
        }
    }

    override fun onCreate() {
        super.onCreate()
        captureThread = HandlerThread("ScreenCapture").apply { start() }
        handler = Handler(captureThread.looper)
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_CAPTURE -> triggerCapture()
            ACTION_STOP -> stopEverything()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        removeFloatingButton()
        handler.post { releaseProjection() }
        captureThread.quitSafely()
        CaptureState.setConnected(false)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- 연결

    private fun handleStart(intent: Intent) {
        ServiceCompat.startForeground(
            this,
            NOTIF_ID_RUNNING,
            buildRunningNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_RESULT_DATA, Intent::class.java)
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopEverything()
            return
        }

        val manager = getSystemService(MediaProjectionManager::class.java)
        val newProjection = try {
            manager.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            Log.e(TAG, "getMediaProjection failed", e)
            null
        }
        if (newProjection == null) {
            stopEverything()
            return
        }
        newProjection.registerCallback(projectionCallback, handler)

        handler.post {
            releaseProjection()
            projection = newProjection
            try {
                createVirtualDisplay()
                mainHandler.post {
                    addFloatingButton()
                    CaptureState.setConnected(true)
                }
            } catch (e: Exception) {
                Log.e(TAG, "createVirtualDisplay failed", e)
                mainHandler.post { stopEverything() }
            }
        }
    }

    private fun createVirtualDisplay() {
        val proj = projection ?: return
        readScreenSize()
        val reader = newImageReader()
        imageReader = reader
        virtualDisplay = proj.createVirtualDisplay(
            "ScreenCapture",
            width, height, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
    }

    private fun newImageReader(): ImageReader =
        ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3).apply {
            setOnImageAvailableListener({ reader -> onImageAvailable(reader) }, handler)
        }

    private fun onImageAvailable(reader: ImageReader) {
        val image = try {
            reader.acquireLatestImage()
        } catch (e: IllegalStateException) {
            null
        } ?: return
        if (reader !== imageReader) {
            image.close()
            return
        }
        latestImage?.close()
        latestImage = image
    }

    @Suppress("DEPRECATION")
    private fun readScreenSize() {
        val display = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        width = metrics.widthPixels
        height = metrics.heightPixels
        densityDpi = metrics.densityDpi
    }

    private fun resizeIfNeeded() {
        val oldW = width
        val oldH = height
        readScreenSize()
        if (oldW == width && oldH == height) return
        val display = virtualDisplay ?: return
        val oldReader = imageReader
        latestImage?.close()
        latestImage = null
        val reader = newImageReader()
        imageReader = reader
        display.resize(width, height, densityDpi)
        display.surface = reader.surface
        oldReader?.close()
    }

    // ---------------------------------------------------------------- 촬영

    /** 메인 스레드: 버튼 숨김 → 잠시 대기 → 캡처. */
    private fun triggerCapture() {
        if (capturing) return
        if (!CaptureState.connected.value || projection == null) {
            Toast.makeText(this, getString(R.string.toast_failed, "화면 미연결"), Toast.LENGTH_SHORT).show()
            return
        }
        capturing = true
        setFloatingVisible(false)
        mainHandler.postDelayed({
            handler.post {
                resizeIfNeeded()
                captureFrame(attempt = 0)
            }
        }, HIDE_SETTLE_MS)
    }

    private fun captureFrame(attempt: Int) {
        val image = latestImage
        if (image == null) {
            if (attempt < FRAME_WAIT_MAX_ATTEMPTS) {
                handler.postDelayed({ captureFrame(attempt + 1) }, FRAME_WAIT_STEP_MS)
            } else {
                finishCapture(null, "화면 프레임을 받지 못했습니다")
            }
            return
        }
        try {
            val bitmap = imageToBitmap(image)
            val capture = saveBitmap(bitmap)
            bitmap.recycle()
            finishCapture(capture, null)
        } catch (e: Exception) {
            Log.e(TAG, "capture failed", e)
            finishCapture(null, e.message ?: e.javaClass.simpleName)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val buffer = plane.buffer.apply { rewind() }
        val needed = rowStride * image.height
        val source: ByteBuffer = if (buffer.remaining() >= needed) {
            buffer
        } else {
            ByteBuffer.allocateDirect(needed).put(buffer).also { it.rewind() }
        }

        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(source)
        if (rowPadding == 0) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun saveBitmap(bitmap: Bitmap): CaptureState.Capture {
        val name = "Screenshot_" +
            SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + ".png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(
                MediaStore.Images.Media.RELATIVE_PATH,
                Environment.DIRECTORY_PICTURES + "/ScreenCapture"
            )
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = contentResolver
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri: Uri = resolver.insert(collection, values)
            ?: throw IOException("갤러리에 파일을 만들 수 없습니다")
        try {
            resolver.openOutputStream(uri)?.use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                    throw IOException("PNG 인코딩 실패")
                }
            } ?: throw IOException("파일을 열 수 없습니다")
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return CaptureState.Capture(uri, name)
    }

    private fun finishCapture(capture: CaptureState.Capture?, error: String?) {
        mainHandler.post {
            capturing = false
            if (capture != null) {
                CaptureState.onCaptured(capture)
                // 그 앱 화면을 저장했으니, 이제 앱을 백그라운드로 보내 안 보이게 한다.
                sendCurrentAppToBackground()
                setFloatingVisible(true)
                Toast.makeText(this, R.string.toast_saved, Toast.LENGTH_SHORT).show()
            } else {
                setFloatingVisible(true)
                Toast.makeText(this, getString(R.string.toast_failed, error), Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * 현재 화면에 떠 있는 앱을 백그라운드로 보낸다(홈 화면으로 나감).
     * 오버레이 권한이 있으므로 백그라운드 액티비티 실행 제한을 우회할 수 있다.
     */
    private fun sendCurrentAppToBackground() {
        val home = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(home)
        } catch (e: Exception) {
            Log.w(TAG, "sendCurrentAppToBackground failed", e)
        }
    }

    // ---------------------------------------------------------------- 플로팅 버튼

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun addFloatingButton() {
        if (floatingView != null) return
        if (!Settings.canDrawOverlays(this)) return

        val wm = getSystemService(WindowManager::class.java)
        val view = LayoutInflater.from(this).inflate(R.layout.floating_button, null)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(160)
        }

        val button = view.findViewById<View>(R.id.floatingButton)
        val touchSlop = dp(8).toFloat()
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        var downTime = 0L

        button.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) dragging = true
                    if (dragging) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        try {
                            wm.updateViewLayout(view, params)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        val held = System.currentTimeMillis() - downTime
                        if (held >= 600) {
                            stopEverything() // 길게 누르면 연결 해제
                        } else {
                            triggerCapture() // 짧게 누르면 촬영
                        }
                    }
                    true
                }
                else -> false
            }
        }

        try {
            wm.addView(view, params)
            floatingView = view
            floatingParams = params
        } catch (e: Exception) {
            Log.e(TAG, "addFloatingButton failed", e)
        }
    }

    private fun setFloatingVisible(visible: Boolean) {
        floatingView?.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun removeFloatingButton() {
        val view = floatingView ?: return
        try {
            getSystemService(WindowManager::class.java).removeView(view)
        } catch (_: Exception) {
        }
        floatingView = null
        floatingParams = null
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- 정리

    private fun releaseProjection() {
        latestImage?.close()
        latestImage = null
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        projection?.let {
            it.unregisterCallback(projectionCallback)
            it.stop()
        }
        projection = null
    }

    /** 메인 스레드: 버튼 제거 + 포그라운드 해제 + 서비스 종료. */
    private fun stopEverything() {
        removeFloatingButton()
        CaptureState.setConnected(false)
        handler.post { releaseProjection() }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ---------------------------------------------------------------- 알림

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildRunningNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            ),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 2,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_capture)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_running))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "연결 해제", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }
}
