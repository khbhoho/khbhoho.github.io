# 스샷캡처 (ScreenCaptureApp)

실행 중인 다른 앱 화면을 찍는 안드로이드 앱입니다.

## 동작 방식
1. **화면 연결 허용** – 시스템의 화면 캡처(MediaProjection) 권한을 한 번 받습니다.
   연결은 포그라운드 서비스가 유지하므로, 해제 전까지 권한 창이 다시 뜨지 않습니다.
2. **스크린샷 찍기** – 이 앱이 `moveTaskToBack()`으로 백그라운드로 내려가고,
   그 아래에 있던 앱(방금 쓰던 앱)이 화면에 나옵니다.
3. 설정한 대기 시간(0.5~5초) 뒤 현재 화면을 캡처해 `Pictures/ScreenCapture`에 PNG로 저장합니다.
4. 촬영 후 이 앱을 다시 앞으로 불러와 원래 상태로 복귀하고, 방금 찍은 사진을 미리보기로 보여줍니다.

알림의 **[지금 촬영]** 버튼을 누르면 앱으로 돌아가지 않고 보고 있는 화면을 바로 찍습니다.

## 자동 복귀 권한
Android 10+ 는 백그라운드 앱이 화면을 띄우는 것을 막습니다.
앱의 **[자동 복귀 권한 허용]** 버튼 → "다른 앱 위에 표시" 를 켜 주세요.
켜지 않으면 촬영은 되지만 자동 복귀가 막힐 수 있고, 이때는 "저장됨" 알림을 눌러 돌아오면 됩니다.

## 열기 / 빌드
- Android Studio → **Open** → 이 폴더(`ScreenCaptureApp`) 선택 → Gradle Sync 후 실행
- 최소 Android 10 (API 29), target API 35
- AGP 8.7.3 / Kotlin 2.0.21 / Gradle 8.11.1 (최신 Android Studio 에서 업그레이드 안내가 뜨면 따라도 됩니다)

## 주요 파일
- `MainActivity.kt` – 화면, 권한 요청, 백그라운드 전환
- `ScreenCaptureService.kt` – MediaProjection 유지, 프레임 캡처, 저장, 앱 복귀
- `CaptureShortcutActivity.kt` – 알림의 [지금 촬영] 버튼
- `CaptureState.kt` – 서비스와 화면 간 상태 공유
